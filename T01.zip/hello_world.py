# Take in a users name
name = input("write your name here: ")
# Print out the name
print(name)

# Take in users age
age = input("Write your age here: ")
# Print out the age
print(age)

print("Hello {} you are {} years old!".format(name, age))

print(" ")

print("Hello World!")
