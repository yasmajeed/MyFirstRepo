# Ask the user to order there 3 favourite food items on a menu using input() 
# Store them as variables item1, item2, and item3

item1 = input("Write your first food item here: ")
item2 = input("Write your second food item here: ")
item3 = input("Write your third food item here: ")

print(item1)
print(item2)
print(item3)

print(item1, item2, item3)
print("Order confirmation, you have ordered {}, {} and {}".format(item1, item2, item3))
